# Misi Tubuh Manusia

Game edukasi soal TKA IPA kelas 8 SMP: **Sistem Peredaran Darah**, **Sistem Pernapasan**, dan **Sistem Ekskresi**.

- 3 level, 5 soal per level (soal dan opsi diacak)
- Lulus level jika benar minimal 3 dari 5
- Sertifikat di akhir permainan (unduh PNG atau cetak)
- Tanpa dependensi: HTML, CSS, dan JavaScript murni

## Menjalankan
Buka `index.html` di browser, atau jalankan server lokal:

    python3 -m http.server 8000

## Deploy ke GitHub Pages
1. Buat repository baru, lalu upload semua file di folder ini.
2. Buka **Settings > Pages**.
3. Pada *Build and deployment*, pilih **Deploy from a branch**, branch `main`, folder `/ (root)`.
4. Simpan. Situs aktif di `https://USERNAME.github.io/NAMA-REPO/`.

## Mengubah soal
Edit array `L` di `script.js`. Setiap soal berbentuk `{q, o, a, e}`: pertanyaan, daftar opsi, indeks jawaban benar (mulai 0), dan penjelasan.
