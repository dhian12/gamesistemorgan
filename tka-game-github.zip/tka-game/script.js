const C=["var(--arteri)","var(--vena)","var(--emas)"];
const L=[
{n:"Sistem Peredaran Darah",ic:"🫀",q:[
{q:"Pembuluh darah yang membawa darah kaya oksigen dari jantung ke seluruh tubuh (selain paru-paru) disebut ....",o:["Arteri","Vena","Kapiler","Vena pulmonalis"],a:0,e:"Arteri membawa darah dari jantung dengan tekanan tinggi, sehingga dindingnya tebal dan elastis."},
{q:"Darah miskin oksigen dari seluruh tubuh pertama kali masuk ke jantung melalui bagian ....",o:["Serambi kanan","Serambi kiri","Bilik kanan","Bilik kiri"],a:0,e:"Vena cava mengalirkan darah dari tubuh ke serambi kanan, lalu ke bilik kanan dan ke paru-paru."},
{q:"Luka Dito sulit berhenti berdarah. Komponen darah yang kemungkinan jumlahnya kurang adalah ....",o:["Trombosit","Eritrosit","Leukosit","Plasma darah"],a:0,e:"Trombosit (keping darah) berperan dalam pembekuan darah dengan bantuan fibrin."},
{q:"Rani bergolongan darah A. Ia dapat menerima transfusi darah dari golongan ....",o:["A dan O","B dan AB","AB saja","B dan O"],a:0,e:"Golongan A memiliki aglutinogen A, sehingga tidak boleh menerima darah yang mengandung aglutinogen B."},
{q:"Dinding bilik kiri jantung lebih tebal daripada bilik kanan karena bilik kiri ....",o:["Memompa darah ke seluruh tubuh dengan tekanan besar","Menerima darah dari paru-paru","Menampung darah dari vena cava","Memompa darah hanya ke paru-paru"],a:0,e:"Sirkulasi besar membutuhkan tekanan lebih tinggi, sehingga otot bilik kiri lebih tebal."}]},
{n:"Sistem Pernapasan",ic:"🫁",q:[
{q:"Urutan jalur udara saat menghirup napas yang benar adalah ....",o:["Hidung – faring – laring – trakea – bronkus – alveolus","Hidung – laring – faring – bronkus – trakea – alveolus","Hidung – trakea – faring – laring – bronkus – alveolus","Hidung – faring – trakea – laring – alveolus – bronkus"],a:0,e:"Udara dari hidung melewati faring, laring, trakea, bronkus, bronkiolus, lalu tiba di alveolus."},
{q:"Pada saat inspirasi (menarik napas) yang terjadi pada tubuh adalah ....",o:["Diafragma mendatar, rongga dada membesar, tekanan udara dalam paru-paru turun","Diafragma melengkung, rongga dada mengecil, tekanan naik","Diafragma mendatar, rongga dada mengecil, tekanan naik","Diafragma melengkung, rongga dada membesar, tekanan turun"],a:0,e:"Kontraksi diafragma dan otot antartulang rusuk memperbesar rongga dada sehingga udara masuk."},
{q:"Pertukaran gas oksigen dan karbon dioksida di dalam paru-paru terjadi di ....",o:["Alveolus melalui difusi","Bronkus melalui osmosis","Trakea melalui difusi","Bronkiolus melalui filtrasi"],a:0,e:"Dinding alveolus sangat tipis dan dikelilingi kapiler darah sehingga gas mudah berdifusi."},
{q:"Saat kita menelan, makanan tidak masuk ke trakea karena ....",o:["Epiglotis menutup pangkal laring","Rambut getar menahan makanan","Diafragma menutup trakea","Alveolus menyaring makanan"],a:0,e:"Epiglotis adalah katup tulang rawan yang menutup jalan napas saat menelan."},
{q:"Ayu mengalami sesak napas dan bunyi mengi saat terkena debu karena saluran bronkusnya menyempit akibat alergi. Penyakit yang dialami Ayu adalah ....",o:["Asma","Tuberkulosis (TBC)","Emfisema","Bronkitis akibat bakteri"],a:0,e:"Asma disebabkan penyempitan saluran napas yang dipicu alergen seperti debu atau udara dingin."}]},
{n:"Sistem Ekskresi",ic:"🧪",q:[
{q:"Organ yang berfungsi menyaring darah dan mengeluarkan urea, garam, serta kelebihan air dalam bentuk urine adalah ....",o:["Ginjal","Hati","Kulit","Paru-paru"],a:0,e:"Ginjal menyaring darah melalui jutaan nefron."},
{q:"Proses penyaringan darah yang menghasilkan urine primer terjadi di ....",o:["Badan Malpighi (glomerulus dan kapsul Bowman)","Tubulus kontortus distal","Lengkung Henle","Tubulus pengumpul"],a:0,e:"Filtrasi di glomerulus menghasilkan filtrat glomerulus (urine primer)."},
{q:"Pada pemeriksaan, urine Budi mengandung glukosa. Kemungkinan Budi menderita ....",o:["Diabetes melitus","Nefritis","Batu ginjal","Anemia"],a:0,e:"Pada diabetes melitus kadar gula darah tinggi, sehingga glukosa tidak seluruhnya direabsorpsi dan ikut keluar bersama urine."},
{q:"Mengapa pada cuaca dingin seseorang lebih sering buang air kecil dibandingkan cuaca panas?",o:["Produksi keringat sedikit sehingga ginjal mengeluarkan lebih banyak air","Ginjal berhenti bekerja saat panas","Hati mengeluarkan lebih banyak urea","Paru-paru mengeluarkan lebih sedikit uap air"],a:0,e:"Saat dingin, kelenjar keringat kurang aktif sehingga kelebihan air dibuang melalui ginjal."},
{q:"Organ yang mengubah amonia hasil pemecahan protein menjadi urea adalah ....",o:["Hati","Ginjal","Pankreas","Kantong kemih"],a:0,e:"Hati mengubah amonia yang beracun menjadi urea, lalu urea dibawa darah ke ginjal untuk dikeluarkan."}]}
];
const app=document.getElementById("app");
let S={name:"",lv:0,qi:0,ok:0,best:[null,null,null],items:[],done:false};
const sh=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const esc=s=>s.replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const total=()=>S.best.reduce((a,b)=>a+(b||0),0);

function home(){
 const unlocked=i=>i===0||(S.best[i-1]!==null&&S.best[i-1]>=3);
 const allDone=S.best.every(b=>b!==null&&b>=3);
 app.innerHTML=`<div class="card hero">
  <h1>Misi Tubuh Manusia</h1>
  <p>Jawab soal TKA IPA kelas 8 tentang peredaran darah, pernapasan, dan ekskresi. Raih minimal 3 jawaban benar di setiap level untuk membuka level berikutnya dan mendapatkan sertifikat.</p>
  ${S.name?`<p><b>Halo, ${esc(S.name)}!</b> Skor terbaikmu: ${total()} jawaban benar.</p>`:`<label for="nm"><b>Nama lengkap untuk sertifikat</b></label><input id="nm" maxlength="40" placeholder="Tulis namamu" autocomplete="name">`}
  <div class="lvls">${L.map((l,i)=>`<div class="lv ${unlocked(i)?'':'lock'}"><div class="ic" style="background:${C[i]}">${l.ic}</div><div style="flex:1"><h3>Level ${i+1}: ${l.n}</h3><small>5 soal${S.best[i]!==null?` · terbaik ${S.best[i]}/5`:''}</small></div><button class="btn" ${unlocked(i)?'':'disabled'} onclick="start(${i})">${S.best[i]!==null?'Ulangi':'Main'}</button></div>`).join("")}</div>
  ${allDone?`<div class="row"><button class="btn" onclick="cert()">Lihat sertifikat</button></div>`:""}
 </div>`;
}
function start(i){
 if(!S.name){const v=document.getElementById("nm").value.trim();if(!v){const n=document.getElementById("nm");n.focus();n.placeholder="Nama wajib diisi dulu";return}S.name=v}
 S.lv=i;S.qi=0;S.ok=0;
 S.items=sh(L[i].q).map(x=>{const opts=sh(x.o.map((t,k)=>({t,r:k===x.a})));return{q:x.q,e:x.e,opts}});
 ask();
}
function ask(){
 const l=L[S.lv],it=S.items[S.qi];
 app.innerHTML=`<div class="top"><span class="chip">Level ${S.lv+1} · ${l.n}</span><span class="chip">Benar: ${S.ok}</span></div>
 <div class="bar"><i style="width:${S.qi/5*100}%;background:${C[S.lv]}"></i></div>
 <div class="card"><p style="color:var(--mute);margin:0 0 6px">Soal ${S.qi+1} dari 5</p><div class="q">${it.q}</div>
 <div id="opts">${it.opts.map((o,k)=>`<button class="opt" onclick="pick(${k})">${String.fromCharCode(65+k)}. ${o.t}</button>`).join("")}</div><div id="fb"></div></div>`;
}
function pick(k){
 const it=S.items[S.qi],good=it.opts[k].r;
 if(good)S.ok++;
 document.querySelectorAll(".opt").forEach((b,i)=>{b.disabled=true;if(it.opts[i].r)b.classList.add("ok");else if(i===k)b.classList.add("bad")});
 const last=S.qi===4;
 document.getElementById("fb").innerHTML=`<div class="exp"><b>${good?"Benar!":"Belum tepat."}</b> ${it.e}</div><button class="btn" onclick="next()">${last?"Lihat hasil":"Soal berikutnya"}</button>`;
 document.querySelector(".chip:last-child").textContent="Benar: "+S.ok;
}
function next(){S.qi++;S.qi>=5?result():ask()}
function result(){
 const pass=S.ok>=3;
 if(S.best[S.lv]===null||S.ok>S.best[S.lv])S.best[S.lv]=S.ok;
 const fin=S.lv===2&&S.best.every(b=>b!==null&&b>=3);
 app.innerHTML=`<div class="card center"><p style="margin:0">Level ${S.lv+1} selesai</p><div class="big" style="color:${C[S.lv]}">${S.ok}/5</div>
 <h2 style="margin:10px 0">${S.ok===5?"Sempurna! 🏆":pass?"Level lulus! 🎉":"Coba lagi ya 💪"}</h2>
 <p>${pass?"Kamu berhasil membuka tahap berikutnya.":"Butuh minimal 3 jawaban benar untuk lulus. Baca penjelasan lalu ulangi."}</p>
 <div class="row">${!pass?`<button class="btn" onclick="start(${S.lv})">Ulangi level</button>`:""}
 ${pass&&S.lv<2?`<button class="btn" onclick="start(${S.lv+1})">Lanjut Level ${S.lv+2}</button>`:""}
 ${fin?`<button class="btn" onclick="cert()">Ambil sertifikat</button>`:""}
 <button class="btn sec" onclick="home()">Menu level</button></div></div>`;
}
function certData(){const t=total();return{t,pr:t===15?"Juara Umum (Emas)":t>=13?"Sangat Baik (Perak)":"Baik (Perunggu)",d:new Date().toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"})}}
function cert(){
 const {t,pr,d}=certData();
 app.innerHTML=`<div class="cert"><p style="letter-spacing:3px;margin:0">SERTIFIKAT PENGHARGAAN</p><h2>Misi Tubuh Manusia</h2>
 <p>Diberikan kepada</p><div class="nm">${esc(S.name)}</div>
 <p>atas keberhasilan menuntaskan 3 level soal TKA IPA Kelas 8<br>Sistem Peredaran Darah, Sistem Pernapasan, dan Sistem Ekskresi</p>
 <p><b>Skor: ${t} dari 15 soal benar</b><br>Predikat: <b>${pr}</b></p><p>${d}</p><div class="seal">🏅</div></div>
 <div class="row"><button class="btn" onclick="dl()">Unduh PNG</button><button class="btn sec" onclick="window.print()">Cetak</button><button class="btn sec" onclick="home()">Kembali ke menu</button></div>
 `;
 window.scrollTo(0,0);
}
function dl(){
 const {t,pr,d}=certData(),W=1600,H=1130,c=document.createElement("canvas");c.width=W;c.height=H;
 const x=c.getContext("2d");x.textAlign="center";
 x.fillStyle="#fffdf5";x.fillRect(0,0,W,H);
 x.strokeStyle="#c9962b";x.lineWidth=14;x.strokeRect(40,40,W-80,H-80);x.lineWidth=4;x.strokeRect(70,70,W-140,H-140);
 const f=(s,w,sz,col,y,fam)=>{x.font=w+" "+sz+"px "+(fam||"'Baloo 2',Nunito,sans-serif");x.fillStyle=col;x.fillText(s,W/2,y)};
 f("SERTIFIKAT PENGHARGAAN","700",34,"#2b2210",190);
 f("Misi Tubuh Manusia","800",96,"#8a5d00",310);
 f("Diberikan kepada","400",34,"#2b2210",400);
 let n=S.name,sz=90;x.font="800 "+sz+"px 'Baloo 2',sans-serif";while(x.measureText(n).width>W-300&&sz>40){sz-=4;x.font="800 "+sz+"px 'Baloo 2',sans-serif"}
 f(n,"800",sz,"#12263a",520);
 const w=x.measureText(n).width;x.fillStyle="#c9962b";x.fillRect(W/2-w/2-20,545,w+40,4);
 f("atas keberhasilan menuntaskan 3 level soal TKA IPA Kelas 8","400",34,"#2b2210",630);
 f("Sistem Peredaran Darah, Sistem Pernapasan, dan Sistem Ekskresi","400",34,"#2b2210",680);
 f("Skor: "+t+" dari 15 soal benar","700",44,"#2b2210",780);
 f("Predikat: "+pr,"700",40,"#8a5d00",840);
 f(d,"400",32,"#2b2210",900);
 const g=x.createRadialGradient(W/2,990,5,W/2,990,60);g.addColorStop(0,"#f6cf5d");g.addColorStop(1,"#c9962b");
 x.fillStyle=g;x.beginPath();x.arc(W/2,990,60,0,7);x.fill();f("★","700",64,"#fffdf5",1012);
 const a=document.createElement("a");a.download="sertifikat-"+S.name.replace(/\s+/g,"-").toLowerCase()+".png";a.href=c.toDataURL("image/png");a.click();
}
home();
